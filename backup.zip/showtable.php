<?php
include "inc/fw.php";
$table = $_POST['table'];
$date = $_POST['date'];
$latin = explode("-", $date);
$title = "Facturas de $table";
include "inc/header.php";
?>
<section class="container-fluid pt-3">
    <div class="row">
        <div class="col-md-1"></div>
            <div class="col-md-10">
                <div id="view1">
					<?php
                    if ($table == "")
                    {
                        echo "<h1>Facturas de Fecha: " . $latin[2] . '/' . $latin[1] . '/' . $latin[0] . "</h1>";
                        $stmt = $conn->prepare("SELECT *, DATE_FORMAT(date,'%d %M %Y') as date FROM invoice WHERE date='$date' ORDER BY date DESC, time DESC");
                    }
                    else
                    {
                        if ($date == "")
                        {
                            echo "<h1>Facturas de: $table</h1>";
                            $stmt = $conn->prepare("SELECT *, DATE_FORMAT(date,'%d %M %Y') as date FROM invoice WHERE tabl='$table' ORDER BY date DESC, time DESC");
                        }
                        else
                        {
                            echo "<h1>Facturas de: $table con Fecha: " . $latin[2] . '/' . $latin[1] . '/' . $latin[0] . "</h1>";
                            $stmt = $conn->prepare("SELECT *, DATE_FORMAT(date,'%d %M %Y') as date FROM invoice WHERE tabl='$table' AND date='$date' ORDER BY date DESC, time DESC");
                        }
                    }
                    $stmt_date = $conn->prepare("SET lc_time_names = 'es_ES'");
                    $stmt_date->execute();
                    $stmt->execute();
                    if ($stmt->rowCount() > 0)
                    {
                        while($row = $stmt->fetch(PDO::FETCH_OBJ))
                        {
                            $partial = explode(",", $row->partial);
                            switch ($row->wait_id)
                            {
                                case 0:
                                    $wait = "Barra";
                                    break;
                                case 1:
                                    $wait = "Charly";
                                    break;
                                default:
                                $wait = "Carmen";
                            }
                            echo '<br><h3>Mesa ' . $row->tabl . ' Atendida por: ' . $wait . '</h3>
                            <h3>Fecha : ' . $row->date . ' - ' . $row->time . '</h3>
                            <div class="row">
                            <div class="column left" style="background-color:#aaa;">
                            <h4>Artículo</h4>
                            </div>
                            <div class="column middle" style="background-color:#bbb; text-align:right;">
                            <h4>Precio</h4>
                            </div>
                            <div class="column right" style="background-color:#ccc; text-align:right;">
                            <h4>Cantidad</h4>
                            </div>
                            <div class="column moreright" style="background-color:#cac; text-align:right;">
                            <h4>Parcial</h4>
                            </div></div>';

                            result($conn, $row); // Llama a la función result, le pasa la conexión, el resultado de la base de datos y un 1.

                            echo '<div class="row">
                            <div class="column left" style="background-color:#aaa;">
                            <h6>' . $product . '</h3>
                            </div>
                            <div class="column middle" style="background-color:#bbb; text-align:right;">
                            <h6>' . $price . '</h3>
                            </div>
                            <div class="column right" style="background-color:#ccc; text-align:right;">
                            <h6>' . $qtty . '</h3>
                            </div>
                            <div class="column moreright" style="background-color:#cac; text-align:right;">';
                            for ($i = 0; $i < count($partial); $i++)
                            {
                                echo '<h6>' . $partial[$i] . '</h3>';
                            }
                            echo '</div></div>
                            <div class="column right" style="background-color:#000; text-align:right; color:white; margin-left:36%">Total + I.V.A.: ' . $row->totaliva . '</div>
                            <br><br>';
                            $product = "";
                            $price = "";
                            $qtty = "";
                        }
                    }

                    function result($conn, $row) // Función result recibe la conexión, las filas de la base de datos $row y un 1 o un 0 para saber de donde se llama.
                    {
                        global $price, $product, $qtty;
                        $eacharticle = [];
                        $qttyArray = explode(",", $row->qtty);
                        $productArray = explode(",", $row->article);
                        for ($i = 0; $i < count($productArray) - 1; $i++)
                        {
                            $eacharticle[$i] = explode(":", $productArray[$i]);
                            if ($i == count($productArray) - 2)
                            {
                                $qtty .= $qttyArray[$i];
                            }
                            else
                            {
                                $qtty .= $qttyArray[$i] . "<br>";
                            }
                        }
                
                        for ($i = 0; $i < count($productArray) - 1; $i++)
                        {
                            $sql_product = "SELECT food, food_price FROM foods WHERE id=" . $eacharticle[$i][1];
                            $stmt = $conn->prepare($sql_product);
                            $stmt->execute();
                            $row_product = $stmt->fetch(PDO::FETCH_OBJ);
                            $product_name = $row_product->food;
                            $product_price = $row_product->food_price;
                            if ($i == count($productArray) - 2)
                            {
                                $product .= $product_name;
                                $price .= number_format((float)$product_price, 2, ',', '.');
                            }
                            else
                            {
                                $product .= $product_name . "<br>"; // Saltos de línea HTML.
                                $price .= number_format((float)$product_price, 2, ',', '.') . "<br>";
                            }
                        }
                    }
					?>
				</div>
            </div>
        <div class="col-md-1"></div>
    </div>
</section>
</body>
</html>