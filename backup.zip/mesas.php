<?php
$title = "Mesas del Restaurante";
include "inc/header.php";
?>
<section class="container-fluid pt-3">
<div id="pc"></div>
    <div id="mobile"></div>
    <div class="row">
        <div class="col-md-1"></div>
            <div class="col-md-10">
                <div id="view1">
                    <br><br><br>
					<button name="mesa1" onclick="window.open('mesa.php?table=Entrada 1')" style="height:180px; width:240px">Entrada 1</button>
					<button name="mesa2" onclick="window.open('mesa.php?table=Entrada 2')" style="height:180px; width:240px">Entrada 2</button>
					<button name="mesa3" onclick="window.open('mesa.php?table=Entrada 3')" style="height:180px; width:240px">Entrada 3</button>
					<button name="mesa4" onclick="window.open('mesa.php?table=Entrada 4')" style="height:180px; width:240px">Entrada 4</button>
					<button name="mesa5" onclick="window.open('mesa.php?table=Barra 1')" style="height:180px; width:240px">Barra 1</button>
					<br>
					<br>
					<button name="mesa6" onclick="window.open('mesa.php?table=Barra 2')" style="height:180px; width:240px">Barra 2</button>
					<button name="mesa7" onclick="window.open('mesa.php?table=Barra 3')" style="height:180px; width:240px">Barra 3</button>
					<button name="mesa8" onclick="window.open('mesa.php?table=Patio 1')" style="height:180px; width:240px">Patio 1</button>
					<button name="mesa9" onclick="window.open('mesa.php?table=Patio 2')" style="height:180px; width:240px">Patio 2</button>
					<button name="mesa10" onclick="window.open('mesa.php?table=Patio 3')" style="height:180px; width:240px">Patio 3</button>
					<br>
					<br>
					<button name="mesa11" onclick="window.open('mesa.php?table=Patio 4')" style="height:180px; width:240px">Patio 4</button>
					<button name="mesa12" onclick="window.open('mesa.php?table=Patio 5')" style="height:180px; width:240px">Patio 5</button>
					<button name="mesa13" onclick="window.open('mesa.php?table=Vereda 1')" style="height:180px; width:240px">Vereda 1</button>
					<button name="mesa14" onclick="window.open('mesa.php?table=Vereda 2')" style="height:180px; width:240px">Vereda 2</button>
					<button name="mesa15" onclick="window.open('mesa.php?table=Vereda 3')" style="height:180px; width:240px">Vereda 3</button>
					<br>
					<br>
					<button name="mesa16" onclick="window.open('mesa.php?table=Mesa 1')" style="height:180px; width:240px">Mesa 1</button>
					<button name="mesa17" onclick="window.open('mesa.php?table=Mesa 2')" style="height:180px; width:240px">Mesa 2</button>
					<button name="mesa18" onclick="window.open('mesa.php?table=Mesa 3')" style="height:180px; width:240px">Mesa 3</button>
					<button name="mesa19" onclick="window.open('mesa.php?table=Mesa 4')" style="height:180px; width:240px">Mesa 4</button>
					<button name="mesa20" onclick="window.open('mesa.php?table=Mesa 5')" style="height:180px; width:240px">Mesa 5</button>
					<br>
					<br>
					<button name="mesa21" onclick="window.open('mesa.php?table=Mesa 6')" style="height:180px; width:240px">Mesa 6</button>
					<button name="mesa22" onclick="window.open('mesa.php?table=Mesa 7')" style="height:180px; width:240px">Mesa 7</button>
					<button name="mesa23" onclick="window.open('mesa.php?table=Mesa 8')" style="height:180px; width:240px">Mesa 8</button>
					<button name="mesa24" onclick="window.open('mesa.php?table=Tablón 1')" style="height:180px; width:240px">Tablón 1</button>
					<button name="mesa25" onclick="window.open('mesa.php?table=Tablón 2')" style="height:180px; width:240px">Tablón 2</button>
					<br>
					<br>
					<button name="mesa26" onclick="window.open('mesa.php?table=Mesa 9')" style="height:180px; width:240px">Mesa 9</button>
					<button name="mesa27" onclick="window.open('mesa.php?table=Mesa 10')" style="height:180px; width:240px">Mesa 10</button>
					<button name="mesa28" onclick="window.open('mesa.php?table=Mesa 11')" style="height:180px; width:240px">Mesa 11</button>
					<button name="mesa29" onclick="window.open('mesa.php?table=Mesa 12')" style="height:180px; width:240px">Mesa 12</button>
					<button name="mesa30" onclick="window.open('mesa.php?table=Mesa 13')" style="height:180px; width:240px">Mesa 13</button>
				</div>
            </div>
        <div class="col-md-1"></div>
    </div>
</section>
<?php
include "inc/footer.html";
?>