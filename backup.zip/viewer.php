<?php
$title = "Ver Facturas por Mesas";
include "inc/header.php";
?>
<section class="container-fluid pt-3">
    <div class="row">
        <div class="col-md-1"></div>
            <div class="col-md-10">
                <div id="view1">
                    <br><br>
                    <button onclick="window.open('search.php')" style="width:220px; height:128px;">Buscar Facturas</button>
                    <button onclick="window.open('show.php')" style="width:220px; height:128px; margin-left:20%;">Ver Todas las Facturas</button>
                </div>
            </div>
        <div class="col-md-1"></div>
    </div>
</section>
</body>
</html>