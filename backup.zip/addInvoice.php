<?php
include "inc/fw.php";
if (isset($_POST["table"]))
{
    for ($i = 0; $i < (count($_POST) - 6) / 4; $i++)
    {
        $id[$i] = $_POST["id" . $i];
        $art[$i] = $_POST["art" . $i];
        $price[$i] = $_POST["price" . $i];
        $qtty[$i] = $_POST["qtty" . $i];
        $partial[$i] = $price[$i] * $qtty[$i];
    }
    $wait = $_POST["wait"];
    $table = $_POST['table'];
    $total = $_POST['total'];
    $iva = $_POST["iva"];
    $totaliva = $total * 1.21;
    $date = $_POST['date'];
    $time = $_POST['time'];

    for ($i = 0; $i < count($id); $i++)
    {
        $article .= $id[$i] . ",";
        $qtty1 .= $qtty[$i] . ",";
        $prices .= $price[$i] . ",";
        $part .= $partial[$i] . ",";
    }

    $stmt = $conn->prepare('INSERT INTO invoice VALUES(:id, :wait_id, :tabl, :article, :price, :qtty, :partial, :total, :iva, :totaliva, :date, :time)');
    $stmt->execute(array(':id' => null, ':wait_id' => $wait, ':tabl' => $table, ':article' => $article, ':price' => $prices, ':qtty' => $qtty1, ':partial' => $part, ':total' => $total, ':iva' => $iva, ':totaliva' => $totaliva, ':date' => $date, ':time' => $time));
    echo "<script>if (!alert('Factura de monto: " . $totaliva . " Alamacenada en la Base de Datos Correctamente.')) window.close('_self')</script>";
}
$title = "Guardando Factura";
include "inc/header.php";
?>
<section class="container-fluid pt-3">
    <div id="pc"></div>
    <div id="mobile"></div>
    <div class="row">
        <div class="col-md-1"></div>
            <div class="col-md-10">
                <div id="view1">
                </div>
            </div>
        <div class="col-md-1"></div>
    </div>
</section>
<?php
include "inc/footer.html";
?>