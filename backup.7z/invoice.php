<?php
include "inc/fw.php";
setlocale(LC_TIME, 'es_ES.UTF-8');
date_default_timezone_set("Europe/London");
$table = $_POST['table'];
$invoice = $_POST['invoice'];
$date = date("Y-m-d");
$time = date("H:i:s");
$total = 0;
$title = "Factura: " . $table;
include "inc/header.php";
if (file_exists($table . ".txt"))
{
	unlink($table . ".txt");
}
?>
<section class="container-fluid pt-3">
    <div class="row">
        <div class="col-md-1"></div>
            <div class="col-md-10">
                <div id="view1">
                    <br><br>
					<?php
					echo '<div id="printable">';
					echo "<h1>Fonda 13</h1>";
					echo "<h2>Ticket " . $table . "</h2>";
						echo '<div class="row">';
						echo '<div class="column left" style="background-color:#aaa;">';
						echo "<h4>Artículo</h4>";
						echo '</div>';
						echo '<div class="column middle" style="background-color:#bbb; text-align:right;">';
						echo "<h4>Precio</h4>";
						echo '</div>';
						echo '<div class="column right" style="background-color:#ccc; text-align:right;">';
						echo "<h4>Cantidad</h4>";
						echo '</div>';
						echo '<div class="column moreright" style="background-color:#cac; text-align:right;">';
						echo "<h4>Parcial</h4>";
						echo '</div>';
						echo '</div>';

					$record = explode (",", $invoice);
					for ($i = 0; $i < count($record) - 1; $i+=4)
					{
						echo '<div class="row">';
						echo '<div class="column left" style="background-color:#aaa;">';
						echo '<h3>' . $record[$i + 1] . "</h3>";
						echo '</div>';
						echo '<div class="column middle" style="background-color:#bbb; text-align:right;">';
						echo '<h3>' . $record[$i + 2] . "</h3>";
						echo '</div>';
						echo '<div class="column right" style="background-color:#ccc; text-align:right;">';
						echo '<h3>' . $record[$i + 3] . "</h3>";
						echo '</div>';
						echo '<div class="column moreright" style="background-color:#cac; text-align:right;">';
						$total += $record[$i + 3] * $record[$i + 2];
						echo '<h3>' . $record[$i + 3] * $record[$i + 2] . "</h3>";
						echo '</div>';
						echo '</div>';
					}
					echo '<div class="column right" style="background-color:#000; text-align:right; color:white; margin-left:36%">Total I.V.A. Incluido: ' . number_format((float)$total * 1.21, 2, ',', '.') . '</div>';
					echo '</div>';
					echo '<br><br><br><br>';
					echo '<form action="addInvoice.php" method="post">';
					echo '<input type="hidden" name="table" value="' . $table . '">';
					$j = 0;
					for ($i = 0; $i < count($record) - 1; $i+=4)
					{
                        echo '<input type="hidden" name="id' . $j . '" value="' . $record[$i] . '">';
						echo '<input type="hidden" name="art' . $j . '" value="' . $record[$i + 1] . '">';
						echo '<input type="hidden" name="price' . $j . '" value="' . $record[$i + 2] . '">';
						echo '<input type="hidden" name="qtty' . $j . '" value="' . $record[$i + 3] . '">';
						$j++;
					}
					echo '<input type="hidden" name="total" value="' . $total . '">';
					echo '<input type="hidden" name="date" value="' . $date . '">';
					echo '<input type="hidden" name="time" value="' . $time . '">';
                    echo '<input type="hidden" name="iva" value="21">';
                    echo '<input type="hidden" name="wait" value="0">';
					echo '<input type="button" onclick="printIt(this.form)" value="Imprimir Ticket" style="width:128px; height:60px;" class="btn btn-warning">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
					echo '<input type="submit" value="Generar Ticket" style="width:128px; height:60px;" class="btn btn-primary">';
					echo '</form>';
					?>
				</div>
            </div>
        <div class="col-md-1"></div>
    </div>
</section>
<?php
include "inc/footer.html";
?>