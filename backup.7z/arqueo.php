<?php
$title = "Arqueo de Caja";
include "inc/header.php";
?>

<section class="container-fluid pt-3">
<div id="pc"></div>
    <div id="mobile"></div>
    <div class="row">
        <div class="col-md-1"></div>
            <div class="col-md-10">
                <div id="view1">
                    <br><br><br><br>
					<h3>Por Favor selecciona la fecha para ver el arqueo</h3>
					<form action="showarqueo.php" method="post">
    					<input type='date' name='start'>
                        <br><br>
                        <input type="submit" value="Ver Facturación del Día" style="width:220px; height:64px;">
					</form>
					<br>
					<br>
					<div style="display:inline">
					<button onclick="window.open('showtotal.php', '_blank')" style="width:220px; height:64px;">Mostrar todas las ventas del año</button>
					<button onclick="window.open('db-backup.php', '_blank')" style="width:220px; height:64px; float:right;">Copia de Respaldo de la Base de Datos</button>
					</div>
				</div>
            </div>
        <div class="col-md-1"></div>
    </div>
</section>
<?php
include "inc/footer.html";
?>