<?php
include "inc/fw.php";
include "inc/modal-dismiss.html";
$title = "Borrando Factura";
include "inc/header.php";
if (isset($_POST["id"]))
{
    $id = $_POST["id"];
    $sql = "DELETE FROM invoice WHERE id=$id";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    if ($stmt->rowCount() > 0) // Lo borró de la base de datos.
    {
        ?>
        <section class="container-fluid pt-3">
            <div class="row">
            <div id="pc"></div>
            <div id="mobile"></div>
                <div class="col-md-1"></div>
                    <div class="col-md-10">
                        <div id="view1">
                            <script>toast(2, 'Se Ha Eliminado la Factura', 'Ten en cuenta que los números de facturas no serán correlativos.');</script>
        <?php
    }
}
?>
                    <br><br>
					<input type="button" value="Cierra Esta Ventana" onclick="window.close()">
				</div>
            </div>
        <div class="col-md-1"></div>
    </div>
</section>
<?php
include "inc/footer.html";
?>